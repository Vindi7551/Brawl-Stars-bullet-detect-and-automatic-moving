#ifndef SCRCPY_OTG_H
#define SCRCPY_OTG_H

#include "common.h"

#include "options.h"
#include "scrcpy.h"

enum scrcpy_exit_code
scrcpy_otg(struct scrcpy_options *options);

#endif
